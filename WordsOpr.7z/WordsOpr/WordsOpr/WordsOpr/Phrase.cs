﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WordsOpr
{
    public class Phrase
    {
        public string Sentence { get; set; }
        public string Kana { get; set; }
        public string Meaning { get; set; }
    }
}
